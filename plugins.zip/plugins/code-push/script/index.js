var AccountManager = require("./management-sdk");
module.exports = AccountManager;

//# sourceMappingURL=index.js.map
