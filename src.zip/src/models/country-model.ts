export class CountryModel {
    isRequested: boolean = false;
    city: string = "";
    country: string = "";
    countryCode: string = "";
    region: string = "";
    regionName: string = "";
    timezone: string = "";
    dial_code: string = "";
}