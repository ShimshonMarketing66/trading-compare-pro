
export class Nexmo{
    verify_id:string = "";
    verify_code:string = "";
    is_phone_number_verified:boolean = false;
    is_verify_code_sent:boolean = false;

}